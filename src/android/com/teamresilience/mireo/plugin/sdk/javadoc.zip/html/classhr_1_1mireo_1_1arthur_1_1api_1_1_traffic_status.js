var classhr_1_1mireo_1_1arthur_1_1api_1_1_traffic_status =
[
    [ "delay_seconds", "classhr_1_1mireo_1_1arthur_1_1api_1_1_traffic_status.html#ab045616efe297b05f582f49a55b4d72f", null ],
    [ "enabled", "classhr_1_1mireo_1_1arthur_1_1api_1_1_traffic_status.html#acc9c866815df8e6ce55cc2779884f7cd", null ],
    [ "installed", "classhr_1_1mireo_1_1arthur_1_1api_1_1_traffic_status.html#a83f368524257e7b3614a62330782cd22", null ],
    [ "internet_available", "classhr_1_1mireo_1_1arthur_1_1api_1_1_traffic_status.html#a50452ca3097a5317cb353de0daf1ef80", null ],
    [ "road_blocked", "classhr_1_1mireo_1_1arthur_1_1api_1_1_traffic_status.html#a3b583ca43666689d587da64486a631f0", null ],
    [ "traffic_state", "classhr_1_1mireo_1_1arthur_1_1api_1_1_traffic_status.html#a998779b713b569cfba909a6ce4e1ec08", null ]
];