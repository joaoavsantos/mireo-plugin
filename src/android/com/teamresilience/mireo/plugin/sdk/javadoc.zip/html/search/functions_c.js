var searchData=
[
  ['registeractivationcode_565',['registerActivationCode',['../classhr_1_1mireo_1_1arthur_1_1api_1_1_easy_a_p_i.html#a89a7a61b02f7f249b32cc1071177d262',1,'hr::mireo::arthur::api::EasyAPI']]],
  ['removegeofence_566',['removeGeoFence',['../classhr_1_1mireo_1_1arthur_1_1api_1_1_easy_a_p_i.html#a37f12b9ea2cc3aff5bfdcc90be41ad89',1,'hr::mireo::arthur::api::EasyAPI']]],
  ['removenotifications_567',['removeNotifications',['../classhr_1_1mireo_1_1arthur_1_1api_1_1_easy_a_p_i.html#a76b22ab09023076c7351bbed19da22e4',1,'hr.mireo.arthur.api.EasyAPI.removeNotifications(final String client_id, final INotificationListener notificationListener, final Result resultListener)'],['../classhr_1_1mireo_1_1arthur_1_1api_1_1_easy_a_p_i.html#a01b9a68bc2daba484f56e42dc80437e8',1,'hr.mireo.arthur.api.EasyAPI.removeNotifications(final String client_id, final int mask, final INotificationListener notificationListener, final Result resultListener)']]],
  ['removeroute_568',['removeRoute',['../classhr_1_1mireo_1_1arthur_1_1api_1_1_easy_a_p_i.html#a79ecff38e6356143c3c9762235e2099d',1,'hr::mireo::arthur::api::EasyAPI']]],
  ['repeatguidance_569',['repeatGuidance',['../classhr_1_1mireo_1_1arthur_1_1api_1_1_easy_a_p_i.html#a52f01b54c426212390ac683fa1d1ec95',1,'hr::mireo::arthur::api::EasyAPI']]],
  ['replacedestination_570',['replaceDestination',['../classhr_1_1mireo_1_1arthur_1_1api_1_1_easy_a_p_i.html#a7b732d056413110253105faa7bda9900',1,'hr::mireo::arthur::api::EasyAPI']]],
  ['requestnotifications_571',['requestNotifications',['../classhr_1_1mireo_1_1arthur_1_1api_1_1_easy_a_p_i.html#aec40aee2ef1a40ee1a647723612dcaae',1,'hr.mireo.arthur.api.EasyAPI.requestNotifications(String client_id, int mask, INotificationListener notificationListener, BoolResult resultListener)'],['../classhr_1_1mireo_1_1arthur_1_1api_1_1_easy_a_p_i.html#a1a66a6ffcc9275e5ce6d16e638b57048',1,'hr.mireo.arthur.api.EasyAPI.requestNotifications(final int mask, final INotificationListener notificationListener, final Result resultListener)']]],
  ['resettodefaults_572',['resetToDefaults',['../classhr_1_1mireo_1_1arthur_1_1api_1_1_easy_a_p_i.html#a06460eea11ad10836dd0438733044cd7',1,'hr::mireo::arthur::api::EasyAPI']]],
  ['restorepurchases_573',['restorePurchases',['../classhr_1_1mireo_1_1arthur_1_1api_1_1_easy_a_p_i.html#abc7207d7df5af0a501f1c409e71cb432',1,'hr::mireo::arthur::api::EasyAPI']]],
  ['rgba_574',['rgba',['../classhr_1_1mireo_1_1arthur_1_1api_1_1_easy_a_p_i.html#a6a714c2e59834c7c6e218ff0df7077c2',1,'hr::mireo::arthur::api::EasyAPI']]]
];
