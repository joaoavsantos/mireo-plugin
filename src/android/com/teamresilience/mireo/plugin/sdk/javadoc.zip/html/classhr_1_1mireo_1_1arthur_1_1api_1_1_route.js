var classhr_1_1mireo_1_1arthur_1_1api_1_1_route =
[
    [ "Subtrip", "classhr_1_1mireo_1_1arthur_1_1api_1_1_route_1_1_subtrip.html", "classhr_1_1mireo_1_1arthur_1_1api_1_1_route_1_1_subtrip" ],
    [ "fromJSON", "classhr_1_1mireo_1_1arthur_1_1api_1_1_route.html#a6a011cce0a5b0ed470562533b127a119", null ],
    [ "completedMeters", "classhr_1_1mireo_1_1arthur_1_1api_1_1_route.html#a7ac571c6e8a030e1cd37926d9595caf3", null ],
    [ "dtgToNext", "classhr_1_1mireo_1_1arthur_1_1api_1_1_route.html#aba500ef0c487777a3bf11ed26d68cfcb", null ],
    [ "elapsedSeconds", "classhr_1_1mireo_1_1arthur_1_1api_1_1_route.html#ac6da9e5ac7c6003a0ec212ebec945ee0", null ],
    [ "isActive", "classhr_1_1mireo_1_1arthur_1_1api_1_1_route.html#a84fd0afe13503ef01e5f1a8538155c66", null ],
    [ "isCompleted", "classhr_1_1mireo_1_1arthur_1_1api_1_1_route.html#acd51b36832c1f963ed6629f822751923", null ],
    [ "isNavigation", "classhr_1_1mireo_1_1arthur_1_1api_1_1_route.html#a11baf1f636137265930a57dba549c3e8", null ],
    [ "metadata", "classhr_1_1mireo_1_1arthur_1_1api_1_1_route.html#a95e7412bf8c423f4e614450f245af7e2", null ],
    [ "name", "classhr_1_1mireo_1_1arthur_1_1api_1_1_route.html#aee5f0118454ca188d26b7db28c890faa", null ],
    [ "remainingMeters", "classhr_1_1mireo_1_1arthur_1_1api_1_1_route.html#af9fba793cddddbdfb3385d3e381f45ae", null ],
    [ "remainingSeconds", "classhr_1_1mireo_1_1arthur_1_1api_1_1_route.html#a22a1d87eecd0bd07a0a1d81b667283fe", null ],
    [ "requestedFeatures", "classhr_1_1mireo_1_1arthur_1_1api_1_1_route.html#aa0e7c5de038c4d065f43e2fe613cedba", null ],
    [ "routeId", "classhr_1_1mireo_1_1arthur_1_1api_1_1_route.html#aca422a5dbbdbf814cbae0abfec3c672e", null ],
    [ "routePoints", "classhr_1_1mireo_1_1arthur_1_1api_1_1_route.html#ad6e1985adf71df3a8f3b015be20da231", null ],
    [ "subtrips", "classhr_1_1mireo_1_1arthur_1_1api_1_1_route.html#a127304cf0edf9db7098ef61bde1ab23e", null ],
    [ "totalMeters", "classhr_1_1mireo_1_1arthur_1_1api_1_1_route.html#a4e6f57616b18a550a8792f7d2330fcc8", null ],
    [ "totalSeconds", "classhr_1_1mireo_1_1arthur_1_1api_1_1_route.html#a2ea4ebdb31a5b0a65b8dd542ebafee30", null ],
    [ "ttgToNext", "classhr_1_1mireo_1_1arthur_1_1api_1_1_route.html#a60a30e238c0902f9eccf6f6d5276e1cc", null ],
    [ "usedFeatures", "classhr_1_1mireo_1_1arthur_1_1api_1_1_route.html#ac2f3e26ad4d0aa888dafe11d94179e61", null ]
];