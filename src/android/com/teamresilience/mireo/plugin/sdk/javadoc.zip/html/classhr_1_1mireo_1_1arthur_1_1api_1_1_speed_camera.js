var classhr_1_1mireo_1_1arthur_1_1api_1_1_speed_camera =
[
    [ "fromJSON", "classhr_1_1mireo_1_1arthur_1_1api_1_1_speed_camera.html#a1b450496e578975fc7b2134172531aea", null ],
    [ "DistanceMeters", "classhr_1_1mireo_1_1arthur_1_1api_1_1_speed_camera.html#aafcdf14f7108662c7263bf7c32aacb13", null ],
    [ "LimitKmh", "classhr_1_1mireo_1_1arthur_1_1api_1_1_speed_camera.html#a95f5c569ab52c300e0b524eefb885b4e", null ]
];