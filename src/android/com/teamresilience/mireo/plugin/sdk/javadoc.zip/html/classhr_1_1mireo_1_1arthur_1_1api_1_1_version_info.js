var classhr_1_1mireo_1_1arthur_1_1api_1_1_version_info =
[
    [ "formatAppVersion", "classhr_1_1mireo_1_1arthur_1_1api_1_1_version_info.html#a41c8a4a7cff80f8d8168d985a493db91", null ],
    [ "fromJSON", "classhr_1_1mireo_1_1arthur_1_1api_1_1_version_info.html#a2e340dac39a17fd9ddc3c443712290f1", null ],
    [ "appVersion", "classhr_1_1mireo_1_1arthur_1_1api_1_1_version_info.html#aca8379cdbe0d45b6e678fcf395cdc7ef", null ],
    [ "buildNumber", "classhr_1_1mireo_1_1arthur_1_1api_1_1_version_info.html#a17f6e1f0d9f606c14c10db4255bf7d59", null ],
    [ "mapVersion", "classhr_1_1mireo_1_1arthur_1_1api_1_1_version_info.html#a0cb4f1a8c8a7c8012b3aa664ee9debe0", null ],
    [ "serial", "classhr_1_1mireo_1_1arthur_1_1api_1_1_version_info.html#a48e0ff2e4fe9724c5bd54fef2cb74f82", null ]
];