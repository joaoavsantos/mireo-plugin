var interfacehr_1_1mireo_1_1arthur_1_1api_1_1_i_notification_listener =
[
    [ "OnAdvice", "interfacehr_1_1mireo_1_1arthur_1_1api_1_1_i_notification_listener.html#ae77741f30bfc5f6d930e0441bbdfb91b", null ],
    [ "OnRoute", "interfacehr_1_1mireo_1_1arthur_1_1api_1_1_i_notification_listener.html#a8d2f4b30c4803e5e79c4f2b967874d3b", null ],
    [ "OnSpeedCamera", "interfacehr_1_1mireo_1_1arthur_1_1api_1_1_i_notification_listener.html#a31f6bbf09afcd3ab949a5cc6825857e4", null ],
    [ "OnSpeedLimit", "interfacehr_1_1mireo_1_1arthur_1_1api_1_1_i_notification_listener.html#ac953c08aa207d087ae15aa319c9fd917", null ]
];