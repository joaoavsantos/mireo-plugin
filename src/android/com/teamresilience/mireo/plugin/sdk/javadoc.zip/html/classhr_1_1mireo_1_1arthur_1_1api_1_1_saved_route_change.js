var classhr_1_1mireo_1_1arthur_1_1api_1_1_saved_route_change =
[
    [ "changeType", "classhr_1_1mireo_1_1arthur_1_1api_1_1_saved_route_change.html#a78ad5ff82379430069d3c437c3d51206", null ],
    [ "itemId", "classhr_1_1mireo_1_1arthur_1_1api_1_1_saved_route_change.html#aa6dabdfeea8892cbfa3d96764e518121", null ],
    [ "REMOVE_ROUTE", "classhr_1_1mireo_1_1arthur_1_1api_1_1_saved_route_change.html#a63340c7d9e8e43b6f9c3651492c0eb6f", null ],
    [ "SAVE_ROUTE", "classhr_1_1mireo_1_1arthur_1_1api_1_1_saved_route_change.html#a9e0eeeaf84c85483d24dfb2ce6d4a6e9", null ]
];