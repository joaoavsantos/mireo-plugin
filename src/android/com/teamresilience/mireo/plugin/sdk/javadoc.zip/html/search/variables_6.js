var searchData=
[
  ['geofence_5fenter_675',['GEOFENCE_ENTER',['../classhr_1_1mireo_1_1arthur_1_1api_1_1_a_p_i.html#a7a8c1301ee2ff8114dcf3cd071c31429',1,'hr::mireo::arthur::api::API']]],
  ['geofence_5fexit_676',['GEOFENCE_EXIT',['../classhr_1_1mireo_1_1arthur_1_1api_1_1_a_p_i.html#a2323a757d86c7328c203062891bfa4c1',1,'hr::mireo::arthur::api::API']]]
];
