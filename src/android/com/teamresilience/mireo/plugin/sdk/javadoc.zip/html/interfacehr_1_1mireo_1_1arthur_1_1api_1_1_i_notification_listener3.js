var interfacehr_1_1mireo_1_1arthur_1_1api_1_1_i_notification_listener3 =
[
    [ "OnGeoFenceEvent", "interfacehr_1_1mireo_1_1arthur_1_1api_1_1_i_notification_listener3.html#a19ac7da42781bb7c540bc0e9d9fa3ea5", null ],
    [ "OnPlaceChanged", "interfacehr_1_1mireo_1_1arthur_1_1api_1_1_i_notification_listener3.html#ac02f4ee18720b115255599814e812d25", null ],
    [ "OnSavedRouteChanged", "interfacehr_1_1mireo_1_1arthur_1_1api_1_1_i_notification_listener3.html#a7cafcd4077edcccef3a01ce56b1eb43d", null ]
];