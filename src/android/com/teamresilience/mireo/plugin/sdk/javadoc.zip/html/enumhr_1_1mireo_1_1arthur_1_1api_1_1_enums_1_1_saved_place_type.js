var enumhr_1_1mireo_1_1arthur_1_1api_1_1_enums_1_1_saved_place_type =
[
    [ "both", "enumhr_1_1mireo_1_1arthur_1_1api_1_1_enums_1_1_saved_place_type.html#a320b19d90242b84f8d411babdf1c5503", null ],
    [ "favorites", "enumhr_1_1mireo_1_1arthur_1_1api_1_1_enums_1_1_saved_place_type.html#abf0fef606816c88213fe75516240e4fb", null ],
    [ "home", "enumhr_1_1mireo_1_1arthur_1_1api_1_1_enums_1_1_saved_place_type.html#ae20c0a4ad8d34be878098ec1a1998ff9", null ],
    [ "recents", "enumhr_1_1mireo_1_1arthur_1_1api_1_1_enums_1_1_saved_place_type.html#a00c5e52d7210a788e5cd42efc74fa5f8", null ],
    [ "work", "enumhr_1_1mireo_1_1arthur_1_1api_1_1_enums_1_1_saved_place_type.html#a32a29e58837d2c36bd130b92c360cf71", null ]
];