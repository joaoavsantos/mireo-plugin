var enumhr_1_1mireo_1_1arthur_1_1api_1_1_enums_1_1_e_cargo_type =
[
    [ "explosives", "enumhr_1_1mireo_1_1arthur_1_1api_1_1_enums_1_1_e_cargo_type.html#aaf30046cb808491854d8adcf0528cd05", null ],
    [ "hazardous", "enumhr_1_1mireo_1_1arthur_1_1api_1_1_enums_1_1_e_cargo_type.html#a84580f2bdc8cc338a117cadb070bc771", null ],
    [ "notdangerous", "enumhr_1_1mireo_1_1arthur_1_1api_1_1_enums_1_1_e_cargo_type.html#a121ce4800c353f78b2eb727c7ec005b6", null ],
    [ "waterharmful", "enumhr_1_1mireo_1_1arthur_1_1api_1_1_enums_1_1_e_cargo_type.html#a7472ce2a3c41ea17b525f30de09e198f", null ]
];