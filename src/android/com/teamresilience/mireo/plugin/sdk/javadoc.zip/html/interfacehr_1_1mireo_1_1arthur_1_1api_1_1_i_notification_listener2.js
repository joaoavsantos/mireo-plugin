var interfacehr_1_1mireo_1_1arthur_1_1api_1_1_i_notification_listener2 =
[
    [ "OnPositionData", "interfacehr_1_1mireo_1_1arthur_1_1api_1_1_i_notification_listener2.html#a01779719cfb4a5a210b2cce2a2da1ef9", null ],
    [ "OnSpeedViolations", "interfacehr_1_1mireo_1_1arthur_1_1api_1_1_i_notification_listener2.html#a4d1db895244abfb882044e0fe2acbd06", null ]
];