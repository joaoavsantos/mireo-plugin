var classhr_1_1mireo_1_1arthur_1_1api_1_1_service_link =
[
    [ "close", "classhr_1_1mireo_1_1arthur_1_1api_1_1_service_link.html#a5ae591df94fc66ccb85cbb6565368bca", null ],
    [ "open", "classhr_1_1mireo_1_1arthur_1_1api_1_1_service_link.html#a9e8555112049fc2b4945120b3c45f8ab", null ]
];