var enumhr_1_1mireo_1_1arthur_1_1api_1_1_enums_1_1_e_route_type =
[
    [ "quickest", "enumhr_1_1mireo_1_1arthur_1_1api_1_1_enums_1_1_e_route_type.html#a008d1a5f2f45d614a77207b9c3f45eea", null ]
];