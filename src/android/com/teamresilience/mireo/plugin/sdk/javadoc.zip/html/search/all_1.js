var searchData=
[
  ['blowupradius_32',['blowupRadius',['../classhr_1_1mireo_1_1arthur_1_1api_1_1_advice.html#a4acab759cc8e977d5c20a097afc965e0',1,'hr::mireo::arthur::api::Advice']]],
  ['boolresult_33',['BoolResult',['../interfacehr_1_1mireo_1_1arthur_1_1api_1_1_easy_a_p_i_1_1_bool_result.html',1,'hr::mireo::arthur::api::EasyAPI']]],
  ['both_34',['both',['../enumhr_1_1mireo_1_1arthur_1_1api_1_1_enums_1_1_saved_place_type.html#a320b19d90242b84f8d411babdf1c5503',1,'hr::mireo::arthur::api::Enums::SavedPlaceType']]],
  ['brokenavoids_35',['brokenAvoids',['../classhr_1_1mireo_1_1arthur_1_1api_1_1_route_candidates_1_1_candidate.html#a41173a17c0a9ea081a5fc0ad7ba7334e',1,'hr::mireo::arthur::api::RouteCandidates::Candidate']]],
  ['brokenavoidstext_36',['brokenAvoidsText',['../classhr_1_1mireo_1_1arthur_1_1api_1_1_route_candidates_1_1_candidate.html#a6d8f99a62a3e1dee0b5877b76819ba22',1,'hr::mireo::arthur::api::RouteCandidates::Candidate']]],
  ['buildnumber_37',['buildNumber',['../classhr_1_1mireo_1_1arthur_1_1api_1_1_version_info.html#a17f6e1f0d9f606c14c10db4255bf7d59',1,'hr::mireo::arthur::api::VersionInfo']]]
];
