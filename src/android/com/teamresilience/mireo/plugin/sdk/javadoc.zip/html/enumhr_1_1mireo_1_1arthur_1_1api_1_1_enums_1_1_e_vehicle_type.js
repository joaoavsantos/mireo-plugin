var enumhr_1_1mireo_1_1arthur_1_1api_1_1_enums_1_1_e_vehicle_type =
[
    [ "passenger", "enumhr_1_1mireo_1_1arthur_1_1api_1_1_enums_1_1_e_vehicle_type.html#a26d7795ab60258e752a1a096fb5197e6", null ],
    [ "pedestrian", "enumhr_1_1mireo_1_1arthur_1_1api_1_1_enums_1_1_e_vehicle_type.html#a44841a6a7738dd6bae973c8f74d7414d", null ],
    [ "taxi", "enumhr_1_1mireo_1_1arthur_1_1api_1_1_enums_1_1_e_vehicle_type.html#a58a38fa63953d0e30646ea469816e304", null ],
    [ "truck", "enumhr_1_1mireo_1_1arthur_1_1api_1_1_enums_1_1_e_vehicle_type.html#aef513b37056233a0b7a1c1db36cadd7c", null ]
];