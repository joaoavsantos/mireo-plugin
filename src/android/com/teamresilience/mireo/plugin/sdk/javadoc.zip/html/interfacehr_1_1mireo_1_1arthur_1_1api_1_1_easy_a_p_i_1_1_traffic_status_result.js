var interfacehr_1_1mireo_1_1arthur_1_1api_1_1_easy_a_p_i_1_1_traffic_status_result =
[
    [ "onTrafficStatus", "interfacehr_1_1mireo_1_1arthur_1_1api_1_1_easy_a_p_i_1_1_traffic_status_result.html#a06426f53aef58dda27274f6e47283b2f", null ]
];