var interfacehr_1_1mireo_1_1arthur_1_1api_1_1_easy_a_p_i_1_1_advice_result =
[
    [ "onAdvice", "interfacehr_1_1mireo_1_1arthur_1_1api_1_1_easy_a_p_i_1_1_advice_result.html#ab01ec0676086878574fb26d8efdbc88e", null ]
];