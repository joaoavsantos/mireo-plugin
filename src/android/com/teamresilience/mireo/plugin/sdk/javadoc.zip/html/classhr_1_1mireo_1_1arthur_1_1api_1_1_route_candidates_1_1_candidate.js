var classhr_1_1mireo_1_1arthur_1_1api_1_1_route_candidates_1_1_candidate =
[
    [ "brokenAvoids", "classhr_1_1mireo_1_1arthur_1_1api_1_1_route_candidates_1_1_candidate.html#a41173a17c0a9ea081a5fc0ad7ba7334e", null ],
    [ "brokenAvoidsText", "classhr_1_1mireo_1_1arthur_1_1api_1_1_route_candidates_1_1_candidate.html#a6d8f99a62a3e1dee0b5877b76819ba22", null ],
    [ "totalMeters", "classhr_1_1mireo_1_1arthur_1_1api_1_1_route_candidates_1_1_candidate.html#a4e6f57616b18a550a8792f7d2330fcc8", null ],
    [ "totalSeconds", "classhr_1_1mireo_1_1arthur_1_1api_1_1_route_candidates_1_1_candidate.html#a2ea4ebdb31a5b0a65b8dd542ebafee30", null ]
];