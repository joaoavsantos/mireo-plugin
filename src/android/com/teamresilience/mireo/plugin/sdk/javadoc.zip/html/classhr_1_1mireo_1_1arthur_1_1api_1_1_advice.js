var classhr_1_1mireo_1_1arthur_1_1api_1_1_advice =
[
    [ "I18", "classhr_1_1mireo_1_1arthur_1_1api_1_1_advice_1_1_i18.html", "classhr_1_1mireo_1_1arthur_1_1api_1_1_advice_1_1_i18" ],
    [ "adviceText", "classhr_1_1mireo_1_1arthur_1_1api_1_1_advice.html#a9f04cbc65aff32e60699d200521af3ce", null ],
    [ "adviceType", "classhr_1_1mireo_1_1arthur_1_1api_1_1_advice.html#a4e82b67365f57e80f8399366896d49fa", null ],
    [ "blowupRadius", "classhr_1_1mireo_1_1arthur_1_1api_1_1_advice.html#a4acab759cc8e977d5c20a097afc965e0", null ],
    [ "currentStreet", "classhr_1_1mireo_1_1arthur_1_1api_1_1_advice.html#a4697b022d5af5dd0a42dd171c0ae60bd", null ],
    [ "entryCourseDeg", "classhr_1_1mireo_1_1arthur_1_1api_1_1_advice.html#a3bf2dcae79ffd643f89fda7e9e43cab5", null ],
    [ "i18", "classhr_1_1mireo_1_1arthur_1_1api_1_1_advice.html#aef56e68d35e2016c13c50b58ea37870f", null ],
    [ "isDestination", "classhr_1_1mireo_1_1arthur_1_1api_1_1_advice.html#aa6ac9019d0dee91bcd202628ce2b8c6c", null ],
    [ "isViaPoint", "classhr_1_1mireo_1_1arthur_1_1api_1_1_advice.html#a64fb78dc2072c5fe0711ccb4e47c7cf5", null ],
    [ "laneInfo", "classhr_1_1mireo_1_1arthur_1_1api_1_1_advice.html#a441a5af3fd96c1b346f942970331e55e", null ],
    [ "latitude", "classhr_1_1mireo_1_1arthur_1_1api_1_1_advice.html#acdb9970b183503c235628d76ed2e7b95", null ],
    [ "longitude", "classhr_1_1mireo_1_1arthur_1_1api_1_1_advice.html#ad656c97ffc90e16160bccc7fc3015758", null ],
    [ "metersToAdvice", "classhr_1_1mireo_1_1arthur_1_1api_1_1_advice.html#a5ff61072645e943fa54a70a710fd7544", null ],
    [ "needsAttention", "classhr_1_1mireo_1_1arthur_1_1api_1_1_advice.html#abf08f6f5a86c13a27ac24f0d3f5064a2", null ],
    [ "next", "classhr_1_1mireo_1_1arthur_1_1api_1_1_advice.html#a943dc2e028ecfe9ee3d38a5bd1841e33", null ],
    [ "nextStreet", "classhr_1_1mireo_1_1arthur_1_1api_1_1_advice.html#a51ac07c5dccb68e9589a2edda4348701", null ],
    [ "roundaboudArcAngle", "classhr_1_1mireo_1_1arthur_1_1api_1_1_advice.html#a470576762bf83729eae09dc0ee95f0d1", null ],
    [ "roundaboutExit", "classhr_1_1mireo_1_1arthur_1_1api_1_1_advice.html#a2be3c976f078840645422864c0feacfb", null ],
    [ "route", "classhr_1_1mireo_1_1arthur_1_1api_1_1_advice.html#a189058e30e1eff837e6b3eef519cde0a", null ],
    [ "secondsToAdvice", "classhr_1_1mireo_1_1arthur_1_1api_1_1_advice.html#a184e12831955beab1f04a51b7c222c01", null ]
];