var annotated_dup =
[
    [ "hr", null, [
      [ "mireo", null, [
        [ "arthur", null, [
          [ "api", null, [
            [ "Advice", "classhr_1_1mireo_1_1arthur_1_1api_1_1_advice.html", "classhr_1_1mireo_1_1arthur_1_1api_1_1_advice" ],
            [ "API", "classhr_1_1mireo_1_1arthur_1_1api_1_1_a_p_i.html", "classhr_1_1mireo_1_1arthur_1_1api_1_1_a_p_i" ],
            [ "APIAsyncRequest", "classhr_1_1mireo_1_1arthur_1_1api_1_1_a_p_i_async_request.html", "classhr_1_1mireo_1_1arthur_1_1api_1_1_a_p_i_async_request" ],
            [ "EasyAPI", "classhr_1_1mireo_1_1arthur_1_1api_1_1_easy_a_p_i.html", "classhr_1_1mireo_1_1arthur_1_1api_1_1_easy_a_p_i" ],
            [ "Enums", "classhr_1_1mireo_1_1arthur_1_1api_1_1_enums.html", [
              [ "AdviceType", "enumhr_1_1mireo_1_1arthur_1_1api_1_1_enums_1_1_advice_type.html", null ],
              [ "Arrow", "enumhr_1_1mireo_1_1arthur_1_1api_1_1_enums_1_1_arrow.html", null ],
              [ "EAvoidMask", "enumhr_1_1mireo_1_1arthur_1_1api_1_1_enums_1_1_e_avoid_mask.html", "enumhr_1_1mireo_1_1arthur_1_1api_1_1_enums_1_1_e_avoid_mask" ],
              [ "ECargoType", "enumhr_1_1mireo_1_1arthur_1_1api_1_1_enums_1_1_e_cargo_type.html", "enumhr_1_1mireo_1_1arthur_1_1api_1_1_enums_1_1_e_cargo_type" ],
              [ "EFamily", "enumhr_1_1mireo_1_1arthur_1_1api_1_1_enums_1_1_e_family.html", null ],
              [ "ERouteType", "enumhr_1_1mireo_1_1arthur_1_1api_1_1_enums_1_1_e_route_type.html", "enumhr_1_1mireo_1_1arthur_1_1api_1_1_enums_1_1_e_route_type" ],
              [ "ESuperFamily", "enumhr_1_1mireo_1_1arthur_1_1api_1_1_enums_1_1_e_super_family.html", null ],
              [ "ETruckType", "enumhr_1_1mireo_1_1arthur_1_1api_1_1_enums_1_1_e_truck_type.html", "enumhr_1_1mireo_1_1arthur_1_1api_1_1_enums_1_1_e_truck_type" ],
              [ "EVehicleType", "enumhr_1_1mireo_1_1arthur_1_1api_1_1_enums_1_1_e_vehicle_type.html", "enumhr_1_1mireo_1_1arthur_1_1api_1_1_enums_1_1_e_vehicle_type" ],
              [ "Lane", "enumhr_1_1mireo_1_1arthur_1_1api_1_1_enums_1_1_lane.html", null ],
              [ "SavedPlaceType", "enumhr_1_1mireo_1_1arthur_1_1api_1_1_enums_1_1_saved_place_type.html", "enumhr_1_1mireo_1_1arthur_1_1api_1_1_enums_1_1_saved_place_type" ],
              [ "TypeFamily", "enumhr_1_1mireo_1_1arthur_1_1api_1_1_enums_1_1_type_family.html", null ]
            ] ],
            [ "GeoAddress", "classhr_1_1mireo_1_1arthur_1_1api_1_1_geo_address.html", "classhr_1_1mireo_1_1arthur_1_1api_1_1_geo_address" ],
            [ "INotificationListener", "interfacehr_1_1mireo_1_1arthur_1_1api_1_1_i_notification_listener.html", "interfacehr_1_1mireo_1_1arthur_1_1api_1_1_i_notification_listener" ],
            [ "INotificationListener2", "interfacehr_1_1mireo_1_1arthur_1_1api_1_1_i_notification_listener2.html", "interfacehr_1_1mireo_1_1arthur_1_1api_1_1_i_notification_listener2" ],
            [ "INotificationListener3", "interfacehr_1_1mireo_1_1arthur_1_1api_1_1_i_notification_listener3.html", "interfacehr_1_1mireo_1_1arthur_1_1api_1_1_i_notification_listener3" ],
            [ "LaneInfo", "classhr_1_1mireo_1_1arthur_1_1api_1_1_lane_info.html", "classhr_1_1mireo_1_1arthur_1_1api_1_1_lane_info" ],
            [ "LinkDied", "interfacehr_1_1mireo_1_1arthur_1_1api_1_1_link_died.html", null ],
            [ "PlaceChange", "classhr_1_1mireo_1_1arthur_1_1api_1_1_place_change.html", "classhr_1_1mireo_1_1arthur_1_1api_1_1_place_change" ],
            [ "PositionData", "classhr_1_1mireo_1_1arthur_1_1api_1_1_position_data.html", "classhr_1_1mireo_1_1arthur_1_1api_1_1_position_data" ],
            [ "RemoteLink", "classhr_1_1mireo_1_1arthur_1_1api_1_1_remote_link.html", "classhr_1_1mireo_1_1arthur_1_1api_1_1_remote_link" ],
            [ "Route", "classhr_1_1mireo_1_1arthur_1_1api_1_1_route.html", "classhr_1_1mireo_1_1arthur_1_1api_1_1_route" ],
            [ "RouteCandidates", "classhr_1_1mireo_1_1arthur_1_1api_1_1_route_candidates.html", "classhr_1_1mireo_1_1arthur_1_1api_1_1_route_candidates" ],
            [ "SavedRouteChange", "classhr_1_1mireo_1_1arthur_1_1api_1_1_saved_route_change.html", "classhr_1_1mireo_1_1arthur_1_1api_1_1_saved_route_change" ],
            [ "ServiceLink", "classhr_1_1mireo_1_1arthur_1_1api_1_1_service_link.html", "classhr_1_1mireo_1_1arthur_1_1api_1_1_service_link" ],
            [ "SpeedCamera", "classhr_1_1mireo_1_1arthur_1_1api_1_1_speed_camera.html", "classhr_1_1mireo_1_1arthur_1_1api_1_1_speed_camera" ],
            [ "TrafficStatus", "classhr_1_1mireo_1_1arthur_1_1api_1_1_traffic_status.html", "classhr_1_1mireo_1_1arthur_1_1api_1_1_traffic_status" ],
            [ "VersionInfo", "classhr_1_1mireo_1_1arthur_1_1api_1_1_version_info.html", "classhr_1_1mireo_1_1arthur_1_1api_1_1_version_info" ],
            [ "Voice", "classhr_1_1mireo_1_1arthur_1_1api_1_1_voice.html", "classhr_1_1mireo_1_1arthur_1_1api_1_1_voice" ]
          ] ]
        ] ]
      ] ]
    ] ]
];