var enumhr_1_1mireo_1_1arthur_1_1api_1_1_enums_1_1_e_truck_type =
[
    [ "delivery", "enumhr_1_1mireo_1_1arthur_1_1api_1_1_enums_1_1_e_truck_type.html#a958a0208c0c36b9d9c071287bdd87ae1", null ],
    [ "trailer", "enumhr_1_1mireo_1_1arthur_1_1api_1_1_enums_1_1_e_truck_type.html#af4ae7fe3a2753c18fa7ffb013da62df8", null ],
    [ "transport", "enumhr_1_1mireo_1_1arthur_1_1api_1_1_enums_1_1_e_truck_type.html#a5a45e8fb7e1c3415e2b59b6437c832f4", null ]
];