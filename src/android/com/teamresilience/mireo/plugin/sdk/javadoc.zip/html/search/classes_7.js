var searchData=
[
  ['placechange_428',['PlaceChange',['../classhr_1_1mireo_1_1arthur_1_1api_1_1_place_change.html',1,'hr::mireo::arthur::api']]],
  ['positiondata_429',['PositionData',['../classhr_1_1mireo_1_1arthur_1_1api_1_1_position_data.html',1,'hr::mireo::arthur::api']]]
];
