var interfacehr_1_1mireo_1_1arthur_1_1api_1_1_easy_a_p_i_1_1_audio_alert_result =
[
    [ "onAlertStatus", "interfacehr_1_1mireo_1_1arthur_1_1api_1_1_easy_a_p_i_1_1_audio_alert_result.html#a37e27a40b8bfc1cc2ba0113f914b2340", null ]
];