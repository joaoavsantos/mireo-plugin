var searchData=
[
  ['versioninfo_386',['VersionInfo',['../classhr_1_1mireo_1_1arthur_1_1api_1_1_version_info.html',1,'hr::mireo::arthur::api']]],
  ['versionresult_387',['VersionResult',['../interfacehr_1_1mireo_1_1arthur_1_1api_1_1_easy_a_p_i_1_1_version_result.html',1,'hr::mireo::arthur::api::EasyAPI']]],
  ['voice_388',['Voice',['../classhr_1_1mireo_1_1arthur_1_1api_1_1_voice.html',1,'hr::mireo::arthur::api']]],
  ['voicelistresult_389',['VoiceListResult',['../interfacehr_1_1mireo_1_1arthur_1_1api_1_1_easy_a_p_i_1_1_voice_list_result.html',1,'hr::mireo::arthur::api::EasyAPI']]]
];
