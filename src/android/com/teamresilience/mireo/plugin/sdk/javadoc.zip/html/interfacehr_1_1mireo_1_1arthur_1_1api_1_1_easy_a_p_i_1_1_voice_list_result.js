var interfacehr_1_1mireo_1_1arthur_1_1api_1_1_easy_a_p_i_1_1_voice_list_result =
[
    [ "onVoiceList", "interfacehr_1_1mireo_1_1arthur_1_1api_1_1_easy_a_p_i_1_1_voice_list_result.html#ac8f75213635a5fd4e44ae0a1fbc540d6", null ]
];