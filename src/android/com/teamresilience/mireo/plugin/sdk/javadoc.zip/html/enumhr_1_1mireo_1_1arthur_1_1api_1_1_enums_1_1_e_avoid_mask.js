var enumhr_1_1mireo_1_1arthur_1_1api_1_1_enums_1_1_e_avoid_mask =
[
    [ "avoid_ferries", "enumhr_1_1mireo_1_1arthur_1_1api_1_1_enums_1_1_e_avoid_mask.html#ad655f3eac7b7f85ff4baad5d18f4723d", null ],
    [ "avoid_highway", "enumhr_1_1mireo_1_1arthur_1_1api_1_1_enums_1_1_e_avoid_mask.html#a08f48515126bc7804959585e7d6568fd", null ],
    [ "avoid_toll_roads", "enumhr_1_1mireo_1_1arthur_1_1api_1_1_enums_1_1_e_avoid_mask.html#a41f82e174671fad3d0db37d4580763b8", null ],
    [ "avoid_unpaved", "enumhr_1_1mireo_1_1arthur_1_1api_1_1_enums_1_1_e_avoid_mask.html#a619490c667439233ad02add18318551a", null ],
    [ "even_iran_roads", "enumhr_1_1mireo_1_1arthur_1_1api_1_1_enums_1_1_e_avoid_mask.html#a306070a28b0a498c741141456726959c", null ],
    [ "even_ring_roads", "enumhr_1_1mireo_1_1arthur_1_1api_1_1_enums_1_1_e_avoid_mask.html#a0fe4f141ae0c22ae6edccc543f89dc98", null ],
    [ "odd_iran_roads", "enumhr_1_1mireo_1_1arthur_1_1api_1_1_enums_1_1_e_avoid_mask.html#aeb18e7a7463d2f14fb643f59a5bd55e8", null ],
    [ "odd_ring_roads", "enumhr_1_1mireo_1_1arthur_1_1api_1_1_enums_1_1_e_avoid_mask.html#a544992fe4bee5574ab97ad296ad5d53f", null ],
    [ "use_palestine", "enumhr_1_1mireo_1_1arthur_1_1api_1_1_enums_1_1_e_avoid_mask.html#aa30fb665e0820d393312177258f1822f", null ],
    [ "use_special", "enumhr_1_1mireo_1_1arthur_1_1api_1_1_enums_1_1_e_avoid_mask.html#aa3756588baedd53873c436a9eb247688", null ]
];