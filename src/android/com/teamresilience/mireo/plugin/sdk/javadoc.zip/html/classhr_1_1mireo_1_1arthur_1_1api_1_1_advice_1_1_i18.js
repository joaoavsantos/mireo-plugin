var classhr_1_1mireo_1_1arthur_1_1api_1_1_advice_1_1_i18 =
[
    [ "distanceToAdvice", "classhr_1_1mireo_1_1arthur_1_1api_1_1_advice_1_1_i18.html#a41bfc9849aefa63d783585f2e412285a", null ],
    [ "distanceToDestination", "classhr_1_1mireo_1_1arthur_1_1api_1_1_advice_1_1_i18.html#afbc497b0646bac518fa35cf1151a403f", null ],
    [ "routeETA", "classhr_1_1mireo_1_1arthur_1_1api_1_1_advice_1_1_i18.html#abae2b27ecea353ca6e78a6383d4e30e0", null ],
    [ "timeToAdvice", "classhr_1_1mireo_1_1arthur_1_1api_1_1_advice_1_1_i18.html#aeb5d8ff90548285fe73c4732714d8896", null ],
    [ "timeToDestination", "classhr_1_1mireo_1_1arthur_1_1api_1_1_advice_1_1_i18.html#ad78b9e1c7b3b35355ff452efe3064b3a", null ],
    [ "units", "classhr_1_1mireo_1_1arthur_1_1api_1_1_advice_1_1_i18.html#aac2d06799e08da38c47e110c4dcc38d8", null ]
];