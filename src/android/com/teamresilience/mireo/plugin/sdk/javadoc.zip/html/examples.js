var examples =
[
    [ "GeoFencesFragment.java", "_geo_fences_fragment_8java-example.html", null ],
    [ "MainActivity.java", "_main_activity_8java-example.html", null ],
    [ "MapFragment.java", "_map_fragment_8java-example.html", null ],
    [ "NotificationsFragment.java", "_notifications_fragment_8java-example.html", null ],
    [ "RouteFragment.java", "_route_fragment_8java-example.html", null ],
    [ "SavedPlacesFragment.java", "_saved_places_fragment_8java-example.html", null ],
    [ "SavedRoutesFragment.java", "_saved_routes_fragment_8java-example.html", null ],
    [ "SearchFragment.java", "_search_fragment_8java-example.html", null ],
    [ "SettingsFragment.java", "_settings_fragment_8java-example.html", null ]
];