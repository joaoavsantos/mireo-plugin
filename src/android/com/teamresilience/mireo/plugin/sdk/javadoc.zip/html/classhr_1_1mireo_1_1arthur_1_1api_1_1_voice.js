var classhr_1_1mireo_1_1arthur_1_1api_1_1_voice =
[
    [ "id", "classhr_1_1mireo_1_1arthur_1_1api_1_1_voice.html#a8aa82b9c425ff9b5c60e2d4aa5f5ecaf", null ],
    [ "language", "classhr_1_1mireo_1_1arthur_1_1api_1_1_voice.html#a5ad208bfc086d0ae93be431eb8959862", null ],
    [ "name", "classhr_1_1mireo_1_1arthur_1_1api_1_1_voice.html#aee5f0118454ca188d26b7db28c890faa", null ],
    [ "selected", "classhr_1_1mireo_1_1arthur_1_1api_1_1_voice.html#a0afbbddf498243b06c246e48f0a0fe67", null ]
];