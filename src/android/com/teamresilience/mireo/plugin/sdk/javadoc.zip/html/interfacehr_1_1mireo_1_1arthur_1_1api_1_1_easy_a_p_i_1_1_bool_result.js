var interfacehr_1_1mireo_1_1arthur_1_1api_1_1_easy_a_p_i_1_1_bool_result =
[
    [ "onResult", "interfacehr_1_1mireo_1_1arthur_1_1api_1_1_easy_a_p_i_1_1_bool_result.html#a0c42960b118144bb088fa9cd3b20d2ed", null ]
];