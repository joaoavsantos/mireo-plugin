var searchData=
[
  ['candidate_407',['Candidate',['../classhr_1_1mireo_1_1arthur_1_1api_1_1_route_candidates_1_1_candidate.html',1,'hr::mireo::arthur::api::RouteCandidates']]]
];
