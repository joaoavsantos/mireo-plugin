var classhr_1_1mireo_1_1arthur_1_1api_1_1_route_1_1_subtrip =
[
    [ "advices", "classhr_1_1mireo_1_1arthur_1_1api_1_1_route_1_1_subtrip.html#a37532da6327439fc01263ffbb66b9644", null ],
    [ "distanceMeters", "classhr_1_1mireo_1_1arthur_1_1api_1_1_route_1_1_subtrip.html#a6e40643af26e7000c1f47608b7c30c83", null ],
    [ "durationSeconds", "classhr_1_1mireo_1_1arthur_1_1api_1_1_route_1_1_subtrip.html#a98527b72ed6a904e611a8892eccac1ca", null ]
];