var interfacehr_1_1mireo_1_1arthur_1_1api_1_1_easy_a_p_i_1_1_advice_list_result =
[
    [ "onAdviceList", "interfacehr_1_1mireo_1_1arthur_1_1api_1_1_easy_a_p_i_1_1_advice_list_result.html#aeaa05c7891a5e633ea8875ad92f52559", null ]
];