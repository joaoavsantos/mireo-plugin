var searchData=
[
  ['geoaddress_417',['GeoAddress',['../classhr_1_1mireo_1_1arthur_1_1api_1_1_geo_address.html',1,'hr::mireo::arthur::api']]],
  ['gpsresult_418',['GpsResult',['../interfacehr_1_1mireo_1_1arthur_1_1api_1_1_easy_a_p_i_1_1_gps_result.html',1,'hr::mireo::arthur::api::EasyAPI']]]
];
