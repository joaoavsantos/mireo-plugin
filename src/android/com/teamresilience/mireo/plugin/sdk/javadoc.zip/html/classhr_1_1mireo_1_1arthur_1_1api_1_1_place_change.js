var classhr_1_1mireo_1_1arthur_1_1api_1_1_place_change =
[
    [ "changeType", "classhr_1_1mireo_1_1arthur_1_1api_1_1_place_change.html#a78ad5ff82379430069d3c437c3d51206", null ],
    [ "place", "classhr_1_1mireo_1_1arthur_1_1api_1_1_place_change.html#ad8d4c684e72d9d6dfa1f703adca14876", null ],
    [ "REMOVE_FAVORITE", "classhr_1_1mireo_1_1arthur_1_1api_1_1_place_change.html#aa462ec002ecec09602125fec386e5d6d", null ],
    [ "REMOVE_HOME", "classhr_1_1mireo_1_1arthur_1_1api_1_1_place_change.html#a0f4c9783af35016b62ca31c3646f6cf5", null ],
    [ "REMOVE_RECENT", "classhr_1_1mireo_1_1arthur_1_1api_1_1_place_change.html#ab878eaa094a33ac801d352e219355501", null ],
    [ "REMOVE_WORK", "classhr_1_1mireo_1_1arthur_1_1api_1_1_place_change.html#a20100e0a0f52bab6b08348c1bb554ff1", null ],
    [ "SET_AS_FAVORITE", "classhr_1_1mireo_1_1arthur_1_1api_1_1_place_change.html#a6c10150a3f53185378a933718ca01add", null ],
    [ "SET_AS_RECENT", "classhr_1_1mireo_1_1arthur_1_1api_1_1_place_change.html#a97a5935169c302f07a72b19f54e34ce6", null ],
    [ "SET_HOME", "classhr_1_1mireo_1_1arthur_1_1api_1_1_place_change.html#a5f275b36282805e7ce7805c0ea02b387", null ],
    [ "SET_WORK", "classhr_1_1mireo_1_1arthur_1_1api_1_1_place_change.html#aa9787936fbab93f0ba7b3823177b4dc1", null ]
];