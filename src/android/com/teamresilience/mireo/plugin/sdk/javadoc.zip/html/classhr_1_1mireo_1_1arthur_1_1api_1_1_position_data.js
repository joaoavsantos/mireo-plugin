var classhr_1_1mireo_1_1arthur_1_1api_1_1_position_data =
[
    [ "fromJSON", "classhr_1_1mireo_1_1arthur_1_1api_1_1_position_data.html#ab393d7ba1e7e36f7681def1cca0a73dd", null ],
    [ "altitude", "classhr_1_1mireo_1_1arthur_1_1api_1_1_position_data.html#a4cd607965967e4b7543a8d1b7680b0eb", null ],
    [ "camera_distance", "classhr_1_1mireo_1_1arthur_1_1api_1_1_position_data.html#ab2b155655c939768745450620bd25e5e", null ],
    [ "camera_limit", "classhr_1_1mireo_1_1arthur_1_1api_1_1_position_data.html#abaf17c516cc9b366f33c51778339943e", null ],
    [ "country_code", "classhr_1_1mireo_1_1arthur_1_1api_1_1_position_data.html#a4470bc5b9edf0ff8e9637f3bc0f951b6", null ],
    [ "course", "classhr_1_1mireo_1_1arthur_1_1api_1_1_position_data.html#af78c39f08e30b1dd5b6ee25cb5c83267", null ],
    [ "current_street_name", "classhr_1_1mireo_1_1arthur_1_1api_1_1_position_data.html#a53ac4816f61c5f771f937fed66e91318", null ],
    [ "latitude", "classhr_1_1mireo_1_1arthur_1_1api_1_1_position_data.html#acdb9970b183503c235628d76ed2e7b95", null ],
    [ "longitude", "classhr_1_1mireo_1_1arthur_1_1api_1_1_position_data.html#ad656c97ffc90e16160bccc7fc3015758", null ],
    [ "quality", "classhr_1_1mireo_1_1arthur_1_1api_1_1_position_data.html#adabffea502f5d80f2e4a80954ff17c40", null ],
    [ "road_type", "classhr_1_1mireo_1_1arthur_1_1api_1_1_position_data.html#a68dc1ca89c371b93363715f43c2ddfd0", null ],
    [ "speed", "classhr_1_1mireo_1_1arthur_1_1api_1_1_position_data.html#abbd5f97423f298d76f4f0499c412332f", null ],
    [ "speed_limit", "classhr_1_1mireo_1_1arthur_1_1api_1_1_position_data.html#a8ec8e2cddd92b141c8019c9f574fc275", null ],
    [ "utc", "classhr_1_1mireo_1_1arthur_1_1api_1_1_position_data.html#a5b80b405c646e952383042be25cdbd6a", null ]
];