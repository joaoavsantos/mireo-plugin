var searchData=
[
  ['favorites_673',['favorites',['../enumhr_1_1mireo_1_1arthur_1_1api_1_1_enums_1_1_saved_place_type.html#abf0fef606816c88213fe75516240e4fb',1,'hr::mireo::arthur::api::Enums::SavedPlaceType']]],
  ['formatted_674',['formatted',['../classhr_1_1mireo_1_1arthur_1_1api_1_1_geo_address.html#a5e0d47b3bf3c5ea129db5d4f8eb0edf0',1,'hr::mireo::arthur::api::GeoAddress']]]
];
